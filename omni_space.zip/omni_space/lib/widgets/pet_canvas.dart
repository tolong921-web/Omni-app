import 'package:flutter/material.dart';

class PetWidget extends StatelessWidget {
  final String species;
  final double size;

  const PetWidget({super.key, required this.species, this.size = 120});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size),
      painter: PetPainter(species: species),
    );
  }
}

class PetPainter extends CustomPainter {
  final String species;
  PetPainter({required this.species});

  @override
  void paint(Canvas canvas, Size size) {
    final double cx = size.width / 2;
    final double cy = size.height / 2;

    final shadowPaint = Paint()..color = Colors.black.withOpacity(0.25);
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, size.height * 0.9), width: size.width * 0.7, height: 12),
      shadowPaint,
    );

    final bodyPaint = Paint()..color = const Color(0xFFFDBA74);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(cx, cy + 10), width: size.width * 0.65, height: size.height * 0.55),
        const Radius.circular(32),
      ),
      bodyPaint,
    );

    final earPath = Path()
      ..moveTo(cx - 35, cy - 15)
      ..lineTo(cx - 20, cy - 45)
      ..lineTo(cx - 5, cy - 15)
      ..close()
      ..moveTo(cx + 5, cy - 15)
      ..lineTo(cx + 20, cy - 45)
      ..lineTo(cx + 35, cy - 15)
      ..close();
    canvas.drawPath(earPath, bodyPaint);

    final eyePaint = Paint()..color = const Color(0xFF0F172A);
    canvas.drawCircle(Offset(cx - 15, cy + 5), 4.5, eyePaint);
    canvas.drawCircle(Offset(cx + 15, cy + 5), 4.5, eyePaint);

    final blushPaint = Paint()..color = const Color(0xFFFB7185).withOpacity(0.4);
    canvas.drawCircle(Offset(cx - 25, cy + 15), 6, blushPaint);
    canvas.drawCircle(Offset(cx + 25, cy + 15), 6, blushPaint);

    final mouthPaint = Paint()
      ..color = const Color(0xFF0F172A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round;

    final mouthPath = Path()
      ..moveTo(cx - 7, cy + 14)
      ..quadraticBezierTo(cx, cy + 19, cx + 7, cy + 14);
    canvas.drawPath(mouthPath, mouthPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
