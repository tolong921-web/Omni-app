import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PetModel {
  String name;
  String species;
  int level;
  int exp;
  Map<String, double> stats;

  PetModel({
    required this.name,
    required this.species,
    this.level = 1,
    this.exp = 0,
    required this.stats,
  });

  Map<String, dynamic> toMap() => {
    'name': name,
    'species': species,
    'level': level,
    'exp': exp,
    'stats': stats,
  };

  factory PetModel.fromMap(Map<String, dynamic> map) => PetModel(
    name: map['name'] ?? 'Mèo Con',
    species: map['species'] ?? 'cat',
    level: map['level'] ?? 1,
    exp: map['exp'] ?? 0,
    stats: Map<String, double>.from(map['stats'] ?? {
      'INT': 0.0, 'DIS': 0.0, 'STR': 0.0, 'VIT': 0.0, 'HAP': 0.0
    }),
  );
}

class AppState extends ChangeNotifier {
  SharedPreferences? _prefs;
  PetModel pet = PetModel(
    name: 'Bơ',
    species: 'cat',
    stats: {'INT': 2.0, 'DIS': 1.0, 'STR': 1.0, 'VIT': 2.0, 'HAP': 3.0},
  );

  int streakDays = 1;
  int todayWaterGlasses = 3;

  AppState() {
    _initPrefs();
  }

  Future<void> _initPrefs() async {
    _prefs = await SharedPreferences.getInstance();
    final petData = _prefs?.getString('pet_data');
    if (petData != null) {
      pet = PetModel.fromMap(jsonDecode(petData));
    }
    streakDays = _prefs?.getInt('streak_days') ?? 1;
    notifyListeners();
  }

  void addExp(int amount, Map<String, double> statGains) {
    pet.exp += amount;
    statGains.forEach((key, val) {
      pet.stats[key] = (pet.stats[key] ?? 0.0) + val;
    });

    int expNeeded = pet.level * 50;
    while (pet.exp >= expNeeded) {
      pet.exp -= expNeeded;
      pet.level++;
      expNeeded = pet.level * 50;
    }
    _savePet();
    notifyListeners();
  }

  void addWater() {
    todayWaterGlasses++;
    addExp(2, {'VIT': 0.2});
    notifyListeners();
  }

  Future<void> _savePet() async {
    await _prefs?.setString('pet_data', jsonEncode(pet.toMap()));
  }
}
